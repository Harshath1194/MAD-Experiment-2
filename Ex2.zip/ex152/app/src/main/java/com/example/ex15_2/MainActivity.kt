package com.example.ex15_2

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.*

class MainActivity : AppCompatActivity() {
    private lateinit var inputField: EditText
    private var input = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        inputField = findViewById(R.id.etInput)
    }

    fun buttonClick(view: View) {
        val button = view as Button
        input += button.text.toString()
        inputField.setText(input)
    }

    fun clearInput(view: View) {
        input = ""
        inputField.setText("")
    }

    fun applyFunction(view: View) {
        val button = view as Button
        val function = button.text.toString()

        try {
            val value = input.toDouble()
            val result = when (function) {
                "sin" -> sin(Math.toRadians(value))
                "cos" -> cos(Math.toRadians(value))
                "tan" -> tan(Math.toRadians(value))
                "sqrt" -> sqrt(value)
                "log" -> log10(value)
                "ln" -> ln(value)
                else -> value
            }
            input = result.toString()
            inputField.setText(input)
        } catch (e: Exception) {
            inputField.setText("Error")
            input = ""
        }
    }

    fun evaluate(view: View) {
        try {
            // Support only simple 2-operand expressions like "3+4", "9mod2", etc.
            val operators = listOf("+", "-", "*", "/", "mod", "pow")
            var result = 0.0

            for (op in operators) {
                if (input.contains(op)) {
                    val parts = input.split(op)
                    if (parts.size == 2) {
                        val a = parts[0].toDouble()
                        val b = parts[1].toDouble()
                        result = when (op) {
                            "+" -> a + b
                            "-" -> a - b
                            "*" -> a * b
                            "/" -> a / b
                            "mod" -> a % b
                            "pow" -> a.pow(b)
                            else -> 0.0
                        }
                        input = result.toString()
                        inputField.setText(input)
                        return
                    }
                }
            }

            inputField.setText("Invalid")
        } catch (e: Exception) {
            inputField.setText("Error")
            input = ""
        }
    }
}
